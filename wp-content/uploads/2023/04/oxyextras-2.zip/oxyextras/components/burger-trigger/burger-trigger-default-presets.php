<?php

/**
 * "slug":"..." and "is_default":true are required params for proper functioning
 * "slug":"slide-to-right","is_default":true,
 */

$default_burger_trigger_presets = array(
	'oxy-burger-trigger' => array(
        
        
        
        

		/**
		 * Button with text
		 */

		json_decode(
		'{"name":"Button with text","slug":"button-with-text","is_default":true,"options":{"original":{"oxy-burger-trigger_start":"closed","oxy-burger-trigger_slug_hamburgerinnerhamburgerinnerafterhamburgerinnerbefore_height":"3","oxy-burger-trigger_button_padding_padding-top":"10","oxy-burger-trigger_button_padding_padding-left":"10","oxy-burger-trigger_button_padding_padding-right":"10","oxy-burger-trigger_button_padding_padding-bottom":"10","oxy-burger-trigger_slug_hamburger___burger_size":"0.8","oxy-burger-trigger_slug_hamburger_background_color":"#ffffff","oxy-burger-trigger_slug_hamburgerbox___burger_size":"0.6","oxy-burger-trigger_text":"Menu","oxy-burger-trigger_slug_hamburgerbox_margin_right":"5"}}}', true),

		
        
        
        /**
		 * Button with text
		 */

		json_decode(
		'', true),
        
        /**
		 * Button with text
		 */

		json_decode(
		'', true),
        
        /**
		 * Button with text
		 */

		json_decode(
		'', true),
        
        
        
	
	

	)
);